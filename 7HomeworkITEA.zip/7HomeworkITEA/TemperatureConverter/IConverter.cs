﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TemperatureConverter
{
    interface IConverter
    {
        double Convert(double tempCelsius);
    }
}
