﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TemperatureConverter
{
    public class Converter:IConverter
    {
        public double tempCelsius { get; set; }

        public Converter()
        {
        }

        public Converter(double tCelsius)
        {
            tempCelsius = tCelsius;
        }

        public double Convert(double tempCelsius)
        {
            double f = tempCelsius * 9 / 5 + 32;
            return f;
        }
    }
}
