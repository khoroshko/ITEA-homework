﻿using System;
using System.IO;
using System.Reflection;

namespace Temp
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly assembly = null;

            try
            {
                assembly = Assembly.Load("TemperatureConverter");
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            Type type = assembly.GetType("TemperatureConverter.Converter");

            Console.WriteLine(new string('_', 30) + " Cвойства класса Converter" + "\n");
            Console.WriteLine("Полное Имя:             {0}", type.FullName);
            Console.WriteLine("Базовый класс:          {0}", type.BaseType);
            Console.WriteLine("Абстрактный:            {0}", type.IsAbstract);
            Console.WriteLine("Это COM объект:         {0}", type.IsCOMObject);
            Console.WriteLine("Запрещено наследование: {0}", type.IsSealed);
            Console.WriteLine("Это class:              {0}", type.IsClass);

            object instance = Activator.CreateInstance(type);
            MethodInfo methodDriver = type.GetMethod("Convert");
            object[] parameters = { 10 };

            var a =methodDriver.Invoke(instance, parameters);
            Console.WriteLine(a);
            Console.ReadKey();
        }
    }
}
